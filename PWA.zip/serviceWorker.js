var cacheName = 'v1';
var cacheFiles = [
	'./',
	'./index.html',
	'./maps.html',
	'./css/styles.css',
	'./image/logo.png',
	'./js/db.js',
]

self.addEventListener('install', function(e) {
	console.log("[ServiceWorker] successfully Installed")
	
	e.waitUntil(
		
		caches.open(cacheName).then(function(cache) {
			
			console.log("[ServiceWorker] Caching cacheFiles");
			return cache.addAll(cacheFiles);
		})
	)
})

self.addEventListener('activate', function(e) {
	console.log("[ServiceWorker] is Activated")
	
	e.waitUntil(
	
		caches.keys().then(function(cacheNames) {
			return Promise.all(cacheNames.map(function(thisCacheName) {
				if (thisCacheName !== cacheName) {
					
					console.log("[ServiceWorker] Removing Cached Files... ", thisCacheName);
					return caches.delete(thisCacheName);
				}
			}))
		})
	)
})

self.addEventListener('fetch', function(e) {
	console.log("[ServiceWorker] Fetching...", e.request.url);
		
	e.respondWith(
	
		caches.match(e.request).then(function(response) {
		
		if (response) {
			
			console.log("[ServiceWorker] exists in cache", e.request.url);
			return response;
		}
		
		return fetch(e.request);
		
		})
	)
})